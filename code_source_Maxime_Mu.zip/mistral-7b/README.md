python Main.py

The model and the model's weights are taken from the following directory:
'/home/support/llm/Mistral-7B-Instruct-v0.2'