execute:

python3 Main.py
